#!/usr/bin/env python

import sys
import re
from nltk.tokenize import word_tokenize

# Download NLTK resources
import nltk
nltk.download('punkt')

# Regular expression pattern to find words
WORD_RE = re.compile(r"[\w']+")

for line in sys.stdin:
    # Tokenize the text
    words = word_tokenize(line.strip())
    
    # Emit (word, 1) pairs
    for word in words:
        print(f"{word}\t1")
