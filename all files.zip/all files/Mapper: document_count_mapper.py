#!/usr/bin/env python3

import sys

# Initialize a set to store unique words in each document
words = set()

for line in sys.stdin:
    # Split the input line into document ID and text
    document_id, text = line.strip().split(',', 1)
    # Tokenize the text by splitting it into words
    text = text.split()
    # Emit (word, document_id) pairs
    for word in text:
        print(f"{word},{document_id}\t1")
        # Add the word to the set of words in the document
        words.add(word)

# Emit special tokens to count the number of documents each word appears in
for word in words:
    print(f"{word},*\t1")
