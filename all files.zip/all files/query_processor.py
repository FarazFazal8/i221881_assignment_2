#!/usr/bin/env python3

import sys
import math

def load_idf_values(idf_file):
    idf_values = {}
    with open(idf_file, 'r') as file:
        for line in file:
            word, idf = line.strip().split('\t', 1)
            idf_values[word] = float(idf)
    return idf_values

def calculate_tf_idf(query, idf_values):
    query_vector = {}
    # Tokenize the query
    words = query.split()
    # Calculate term frequency for each word in the query
    for word in words:
        query_vector[word] = query_vector.get(word, 0) + 1
    # Calculate TF/IDF for each term in the query
    for word, tf in query_vector.items():
        if word in idf_values:
            idf = idf_values[word]
            query_vector[word] = tf * idf
    return query_vector

def cosine_similarity(query_vector, document_vector):
    dot_product = sum(query_vector[word] * document_vector.get(word, 0) for word in query_vector)
    query_norm = math.sqrt(sum(value ** 2 for value in query_vector.values()))
    doc_norm = math.sqrt(sum(value ** 2 for value in document_vector.values()))
    if query_norm == 0 or doc_norm == 0:
        return 0
    else:
        return dot_product / (query_norm * doc_norm)

def main(query, idf_file, index_file):
    idf_values = load_idf_values(idf_file)
    relevant_documents = {}

    # Load index file
    with open(index_file, 'r') as file:
        for line in file:
            word, doc_vectors = line.strip().split('\t', 1)
            doc_vectors = eval(doc_vectors)  # Convert string to dictionary
            for doc_id, tfidf_vector in doc_vectors.items():
                similarity = cosine_similarity(query_vector, tfidf_vector)
                if similarity > 0:
                    relevant_documents[doc_id] = similarity
    
    # Sort relevant documents by similarity scores
    sorted_documents = sorted(relevant_documents.items(), key=lambda x: x[1], reverse=True)
    return sorted_documents

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: query_processor.py <query> <idf_file> <index_file>")
        sys.exit(1)

    query = sys.argv[1]
    idf_file = sys.argv[2]
    index_file = sys.argv[3]

    sorted_documents = main(query, idf_file, index_file)
    for doc_id, similarity in sorted_documents:
        print(f"{doc_id}\t{similarity}")
