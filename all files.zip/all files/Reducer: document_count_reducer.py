#!/usr/bin/env python3

import sys

current_word = None
word_count = 0
document_count = 0

for line in sys.stdin:
    word, count = line.strip().split('\t', 1)
    count = int(count)
    
    if word != current_word:
        # If a new word is encountered, emit the document count for the previous word
        if current_word:
            print(f"{current_word}\t{document_count}")
        current_word = word
        word_count = 0
        document_count = 0

    if word_count == 0:
        # If encountering the special token for document count, update the document count
        if word == "*":
            document_count += 1
        else:
            # Otherwise, increment the word count
            word_count += 1

# Emit the document count for the last word
if current_word:
    print(f"{current_word}\t{document_count}")
