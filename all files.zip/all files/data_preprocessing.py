import pandas as pd
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Download NLTK resources
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

def preprocess_text(text):
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    # Remove punctuation and special characters
    text = re.sub(r'[^\w\s]', '', text)
    # Convert text to lowercase
    text = text.lower()
    return text

def tokenize_and_lemmatize(text):
    tokens = word_tokenize(text)
    lemmatizer = WordNetLemmatizer()
    lemmatized_tokens = [lemmatizer.lemmatize(token) for token in tokens]
    return lemmatized_tokens

def remove_stopwords(tokens):
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [token for token in tokens if token not in stop_words]
    return filtered_tokens

# Read a small portion of data from CSV
data = pd.read_csv('/home/i226181/Downloads/enwiki-20170820.csv', nrows=1000)  # Adjust nrows according to your needs

# Apply preprocessing steps
data['SECTION_TEXT'] = data['SECTION_TEXT'].apply(preprocess_text)
data['SECTION_TEXT'] = data['SECTION_TEXT'].apply(tokenize_and_lemmatize)
data['SECTION_TEXT'] = data['SECTION_TEXT'].apply(remove_stopwords)

# Save preprocessed data to a new CSV file
data.to_csv('preprocessed_data.csv', index=False)
