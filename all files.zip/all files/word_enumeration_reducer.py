#!/usr/bin/env python

import sys

current_word = None
current_count = 0

for line in sys.stdin:
    # Split the input line into word and count
    word, count = line.strip().split('\t', 1)
    
    # Convert count to int
    try:
        count = int(count)
    except ValueError:
        # If count is not a valid integer, ignore this line
        continue
    
    if current_word == word:
        # If the word is the same as the previous one, increment count
        current_count += count
    else:
        # If it's a new word, emit the (word, total_count) pair
        if current_word:
            print(f"{current_word}\t{current_count}")
        # Update current_word and current_count
        current_word = word
        current_count = count

# Don't forget to emit the last (word, total_count) pair
if current_word:
    print(f"{current_word}\t{current_count}")
