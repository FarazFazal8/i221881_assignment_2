#!/usr/bin/env python3

import sys
import math

current_word = None
doc_term_freq = {}
doc_count = 0

for line in sys.stdin:
    word, doc_freq = line.strip().split('\t', 1)
    doc_id, term_freq = doc_freq.split(',', 1)
    term_freq = int(term_freq)

    if word != current_word:
        # If a new word is encountered, calculate TF/IDF for the previous word
        if current_word:
            idf = math.log10(doc_count / len(doc_term_freq))
            # Calculate TF/IDF for each document
            tfidf_values = {doc: freq * idf for doc, freq in doc_term_freq.items()}
            # Emit (document_id, sparse_vector) pairs
            print(f"{current_word}\t{tfidf_values}")
        current_word = word
        doc_term_freq = {}
    
    # Store term frequency for the current word and document
    doc_term_freq[doc_id] = term_freq
    doc_count += 1

# Calculate TF/IDF for the last word
if current_word:
    idf = math.log10(doc_count / len(doc_term_freq))
    tfidf_values = {doc: freq * idf for doc, freq in doc_term_freq.items()}
    print(f"{current_word}\t{tfidf_values}")
