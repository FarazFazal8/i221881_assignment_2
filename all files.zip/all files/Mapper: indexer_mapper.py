#!/usr/bin/env python3

import sys

for line in sys.stdin:
    # Split the input line into document ID and text
    document_id, text = line.strip().split(',', 1)
    # Tokenize the text by splitting it into words
    words = text.split()
    # Create a dictionary to store the term frequencies
    term_freq = {}
    # Count the frequency of each word in the document
    for word in words:
        term_freq[word] = term_freq.get(word, 0) + 1
    # Emit (word, (document_id, term_frequency)) pairs
    for word, freq in term_freq.items():
        print(f"{word}\t{document_id},{freq}")
